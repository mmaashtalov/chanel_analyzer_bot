# Chanel Analyzer Bot — Telegram Intelligence Platform

Готовая к запуску Telegram-first OSINT / Intelligence платформа с веб-панелью настройки и встроенным эмулятором.

## Быстрый запуск

```bash
cp .env.example .env
docker compose up -d --build
```

Откройте `http://localhost:8080`.

В Control Center:

1. введите Telegram Bot Token;
2. введите Telegram API ID и API Hash;
3. вставьте Telethon String Session;
4. сохраните конфигурацию;
5. примените миграции;
6. нажмите **Запустить**.

PostgreSQL поднимается автоматически внутри Docker Compose. Секреты хранятся в отдельном Docker volume `/data/config` с правами `0600` и не попадают в GitHub или ответы API.

## Эмулятор

Вкладка **Эмулятор** работает сразу, без Telegram-ключей и внешней БД. Она показывает полный workflow:

`Sources → Workspace → Evolution → Claims → Evidence → Verification → Acquisition → Source Independence → Claim Timeline`.

Эмулятор предоставляет исходные JSON/PDF, integrity hashes и self-test.

## Control Center API

- `GET /health` — процесс Control Center;
- `GET /ready` — готовность demo-артефактов;
- `GET /api/status` — состояние продукта без раскрытия секретов;
- `POST /api/config` — сохранить конфигурацию;
- `POST /api/migrate` — применить Alembic migrations;
- `POST /api/start` — запустить основной Telegram-продукт;
- `POST /api/stop` — остановить;
- `POST /api/restart` — перезапустить;
- `GET /emulator` — встроенный эмулятор.

## Режимы

- `APP_MODE=setup` — Control Center, рекомендуемый режим;
- `APP_MODE=production` — прямой запуск Telegram-платформы из environment;
- `APP_MODE=demo` — автономная публичная демонстрация.

## Проверка

```bash
python -m compileall -q app tests
pytest -q
```

Текущий релиз: **0.22.0-product**. Regression: **94/94**.

## Безопасность

- секреты не логируются и не возвращаются API;
- файл настроек создаётся с правами `0600`;
- RSS/Web acquisition имеет SSRF-защиту;
- ingestion ограничен source plan конкретного Workspace;
- provenance и review-события защищены SHA-256 integrity hashes.

## Ограничения

Для реального Telegram-сбора требуется заранее созданная Telethon String Session. Для production-развёртывания рекомендуется заменить стандартный пароль PostgreSQL, закрыть Control Center внешней авторизацией/reverse proxy и настроить инфраструктурную egress policy.
