#!/bin/sh
set -eu
command -v docker >/dev/null 2>&1 || { echo "Docker не установлен"; exit 1; }
docker compose up -d --build
echo "Control Center: http://localhost:${CONTROL_CENTER_PORT:-8080}"
